<?php $__env->startSection('content'); ?>

    <div class="row h-100 justify-content-center align-items-center">
        <div class="card mt-5" style="width: 25rem;">
            <div class="card-body">
                <h2 class="card-title">New Co. Dashboard</h2>
                <div class="card-body">
                    Hello, <?php echo e($user->name); ?> (<?php echo e($user->email); ?>).
                    <div>
                        <br>
                        You've logged in using <?php echo e($user->password === null ? 'Google SSO' : 'an email/password'); ?>.
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.authenticated', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/cfenn/Work/BCIT/COMP4669/Week7/in-class-project/resources/views/dashboard.blade.php ENDPATH**/ ?>