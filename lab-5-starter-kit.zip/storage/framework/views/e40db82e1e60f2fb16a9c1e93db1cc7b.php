<?php $__env->startSection('content'); ?>

    <div class="row h-100 justify-content-center align-items-center">
        <div class="card" style="width: 25rem;">
            <div class="card-body">
                <h2 class="card-title text-center">NewCo. Login</h2>
                <div class="card-body">
                    <p class="text-center">Don't have an account? <a href="/register" class="card-link">Register</a></p>

                    <br>

                    <div class="text-center">
                        <a href="/auth/redirect"><img src="<?php echo e(asset('images/google-sign-in-btn.png')); ?>"
                                                      width="300"/></a>
                    </div>

                    <br>
                    <h5>or email and password</h5>
                    <br>

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('login')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="emailInput">Email address</label>
                            <input type="email" class="form-control" id="emailInput" name="email" aria-describedby="emailHelp" placeholder="Enter email">
                            <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                        </div>
                        <br>
                        <div class="form-group">
                            <label for="passwordInput">Password</label>
                            <input type="password" name="password" class="form-control" id="passwordInput" placeholder="Password">
                        </div>
                        <br>
                        <button type="submit" class="btn btn-primary w-100">Login</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<style>
    h5 {
        overflow: hidden;
        text-align: center;
    }

    h5:before,
    h5:after {
        background-color: #000;
        content: "";
        display: inline-block;
        height: 1px;
        position: relative;
        vertical-align: middle;
        width: 50%;
    }

    h5:before {
        right: 0.5em;
        margin-left: -50%;
    }

    h5:after {
        left: 0.5em;
        margin-right: -50%;
    }
</style>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/cfenn/Work/BCIT/COMP4669/Week7/in-class-project/resources/views/login.blade.php ENDPATH**/ ?>