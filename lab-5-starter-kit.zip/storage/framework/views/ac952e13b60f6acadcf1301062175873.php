<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js', 'resources/css/app.scss']); ?>
</head>
<body>

<nav class="navbar navbar-expand-lg bg-dark" data-bs-theme="dark">
    <div class="container-fluid">
        <a class="navbar-brand text-white" href="<?php echo e(route('dashboard')); ?>">New Co.</a>

        <form action="<?php echo e(route('logout')); ?>" method="post" class="d-flex">
            <?php echo csrf_field(); ?>
            <input type="submit" value="Logout" class="btn btn-outline-info d-flex">
        </form>
    </div>
</nav>

<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>

</body>
</html>
<?php /**PATH /Users/cfenn/Work/BCIT/COMP4669/Week7/in-class-project/resources/views/layouts/authenticated.blade.php ENDPATH**/ ?>