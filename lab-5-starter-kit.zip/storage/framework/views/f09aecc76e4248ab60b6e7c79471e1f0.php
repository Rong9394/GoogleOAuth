<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js', 'resources/css/app.scss']); ?>
</head>
<body>

<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>


</body>
</html>
<?php /**PATH /Users/cfenn/Work/BCIT/COMP4669/Week7/in-class-project/resources/views/layouts/main.blade.php ENDPATH**/ ?>